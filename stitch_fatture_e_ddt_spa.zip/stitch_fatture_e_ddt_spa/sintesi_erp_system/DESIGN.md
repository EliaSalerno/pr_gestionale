---
name: Sintesi ERP System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#45474c'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fc'
  on-secondary-container: '#57657a'
  tertiary: '#00113b'
  on-tertiary: '#ffffff'
  tertiary-container: '#002367'
  on-tertiary-container: '#5f8aff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#d5e3fc'
  secondary-fixed-dim: '#b9c7df'
  on-secondary-fixed: '#0d1c2e'
  on-secondary-fixed-variant: '#3a485b'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  data-mono:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

Il sistema di design adotta un approccio **minimalista, razionale e puramente funzionale**, concepito appositamente per software gestionali ad alta densità di dati (fatturazione, DDT, bolle di accompagnamento, anagrafiche e magazzino). 

L'estetica elimina qualsiasi ornamento visuale non essenziale, focalizzandosi su:
- **Chiarezza percettiva**: architettura delle informazioni gerarchica e lineare per ridurre il carico cognitivo dell'operatore.
- **Precisione svizzera**: allineamenti rigorosi, griglie geometriche stabili e uso esclusivo di spaziature modulari.
- **Massima accessibilità (WCAG 2.1 AA/AAA)**: indicatori di stato netti, focus ring a contrasto elevato e distinzioni basate non solo sul colore ma su testo e forma.
- **Resistenza alla fatica visiva**: palette sobria monocromatica per sessioni di lavoro prolungate senza abbagliamenti o distrazioni.

## Colors

Il colore in questo sistema ha una funzione tassativamente strutturale ed informativa. La palette poggia su una scala neutra slate/ardesia a bassissima saturazione per supportare sia il tema chiaro (`light`) sia il tema scuro (`dark`) tramite token semantici intercambiabili.

### Ruolo dei colori chiave
- **Primary (`#1e293b`)**: identifica l'azione strutturale cardine e il testo di massima enfasi nel tema chiaro (e la sua controparte speculare ad alto contrasto nel tema scuro `#f8fafc`).
- **Secondary (`#475569`)**: utilizzato per contorni di sezione, etichette secondarie, breadcrumb e stati inattivi.
- **Tertiary / Accent funzionale (`#2563eb`)**: cobalto bilanciato riservato esclusivamente all'affordance interattiva: focus ring ad alto contrasto, selezione di righe di tabelle e link contestuali.
- **Neutral (`#0f172a`)**: ancora per la massima leggibilità tipografica.

### Indicatori di stato semantici per il gestionale
- **Bozza / Aperto**: Neutro slate (`#64748b`).
- **Confermato / Emesso / Pagato**: Smeraldo desaturato (`#16a34a`).
- **In attesa / Parziale**: Ambra operativo (`#d97706`).
- **Annullato / Scaduto / Errore**: Rosso vermiglio controllato (`#dc2626`).

## Typography

La tipografia è unificata sotto la famiglia **Inter**, selezionata per la neutralità, il disegno aperto dei glifi e la resa impeccabile su schermi complessi e densi di valori numerici.

### Regole per dati gestionali
- **Numeri tabulari (`font-feature-settings: 'tnum' 1`)**: obbligatori per importi IVA, quantità, codici articolo, imponibili e date. Consente l'allineamento verticale naturale all'interno delle colonne contabili.
- **Rigorosa gerarchia**: Titoli essenziali e compatti per non sprecare spazio verticale a scapito dei record documentali.
- **Pesi limitati**: Utilizzo rigoroso di `400` (dati/corpo), `500` (etichette form/pulsanti) e `600` (titoli/stati attivi).

## Layout & Spacing

Il layout segue una griglia razionale a 12 colonne fluida, con barra di navigazione laterale fissa e area operativa a densità variabile. La cadenza verticale e orizzontale si basa su un modulo rigoroso di 4px/8px.

### Breakpoint e comportamento
- **Desktop (≥ 1280px)**: Sidebar estesa fissa (240px), padding di pagina `1.5rem` (`24px`), tabelle dati a vista completa con colonne sticky per ID e Totali.
- **Laptop / Tablet orizzontale (1024px - 1279px)**: Sidebar collassata a sole icone (64px), padding `1rem` (`16px`), tabelle con scorrimento orizzontale nativo.
- **Tablet verticale e Mobile (< 1024px)**: Sidebar trasformata in cassetto laterale sovrapposto (drawer), margini ridotti a `0.75rem` (`12px`), le righe complesse di DDT e Fatture si trasformano da tabella in schede di riepilogo a blocco.

## Elevation & Depth

Questo sistema ripudia ombre spesse, riflessi e sfocature decorative. La profondità viene generata unicamente mediante **bordi a basso contrasto e stratificazione tonale**:

- **Livello 0 (Canvas)**: Sfondo principale dell'applicazione (`#f8fafc` in light mode, `#090d16` in dark mode).
- **Livello 1 (Superfici di lavoro e tabelle)**: Pannelli bianchi puri o ardesia scura delimitati da un bordo continuo di 1px (`#e2e8f0` in light mode, `#1e293b` in dark mode).
- **Livello 2 (Menu a discesa, datepicker, autocomplete)**: Superficie sopraelevata contenuta da un bordo da 1px e supportata da un'ombra d'ambiente ultra-sottile (`0 4px 12px rgba(0, 0, 0, 0.06)`).
- **Livello 3 (Modali e drawer di dettaglio)**: Pannello isolato delimitato da bordo con backdrop neutro scuro a trasparenza ridotta (`rgba(15, 23, 42, 0.4)`).

## Shapes

La geometria del design system è controllata e sobria (`roundedness: 1`). 

- Tutti i componenti standard interattivi (input, bottoni, badge, righe selezionabili) adottano un raggio di curvatura di **4px (`0.25rem`)**.
- I contenitori più ampi (tabelle, schede riepilogo, modali) utilizzano **6px o 8px (`0.5rem`)**.
- Questo approccio conserva la percezione di ordine e solidità tipica dei software di produttività, evitando sia la durezza eccessiva degli angoli vivi (0px) sia la frivolezza dei raggi ampi e delle forme a pillola.

## Components

### 1. Focus Ring Universale (Accessibilità WCAG AAA)
Tutti gli elementi interattivi sottoposti a navigazione da tastiera (`Tab`) presentano un anello di focus uniforme:
- Bordo netto offset da `2px` con outline pieno di `2px` colore `#2563eb` (o `#60a5fa` in dark mode). Nessuna soppressione del focus nativo senza questa alternativa esplicita.

### 2. Tabelle Dati (Data Grids per Fatture, DDT, Bolle)
- **Header**: Altezza fissa `36px`, tipografia `label-sm`, testo in maiuscolo leggero, sfondo neutro tenue (`#f1f5f9`), bordo inferiore da 1px.
- **Righe**: Altezza `40px` (densità normale) o `32px` (densità compatta), separate da bordo inferiore continuo da 1px (`#f1f5f9`).
- **Allineamento celle**: Testo allineato a sinistra; valori valuta, quantità e codici numerici allineati rigidamente a destra con glifi tabulari.
- **Hover e selezione**: Hover riga con transizione immediata a tinta neutra tenue; riga selezionata evidenziata da bordo sinistro attivo di `3px` colore `#2563eb`.

### 3. Campi di Input & Selettori
- Altezza standard `36px` con padding orizzontale di `0.5rem` (`8px`).
- Bordo standard neutro `1px solid #cbd5e1`, sfondo pulito. In stato di hover il bordo scurisce a `#94a3b8`.
- In caso di errore contabile o validazione fallita: bordo rosso `#dc2626` e messaggio contestuale a comparsa sottostante in `body-sm`.

### 4. Pulsanti (Buttons)
- **Primario**: Sfondo solido `#1e293b`, testo `#ffffff`, senza gradiente.
- **Secondario / Neutro**: Sfondo trasparente, bordo `1px solid #cbd5e1`, testo `#334155`.
- **Distruttivo**: Bordo o sfondo rosso semantico per eliminazione documenti o righe contabili.
- **Pulsante icona compatto**: Dimensioni `32x32px` per azioni in-riga (stampa bolla, duplica fattura, elimina riga DDT).

### 5. Badge & Chip di Stato
- Spessore compatto, altezza `22px`, padding orizzontale `6px`, raggio `4px`.
- Sfondi a desaturazione controllata con testo coordinato ad alto contrasto per garantire rapporto minimo di contrasto 4.5:1.

### 6. Componente Riga Dettaglio Documento (Articoli / Voci Fattura)
- Layout a griglia modulare per consentire inserimento continuo tramite tastiera (Codice Articolo, Descrizione, U.M., Quantità, Prezzo Unitario, Sconto, Aliquota IVA, Totale Riga).
- Navigazione `Enter`/`Tab` ottimizzata senza interruzioni del mouse.